import nodemailer from 'nodemailer'

const emailRegistro = async (datos) => {
    var transport = nodemailer.createTransport({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT,
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });


    const { nombre, email, token } = datos

    //enviar email
    await transport.sendMail({
        from: 'Bienes Raices',
        to: email,
        subject: 'Confirma tu cuenta de Bienes Raices',
        text: 'envia algo',
        html: `
    <p> hola ${nombre}, comprueba tu cuenta </p >
    <p> Confirma tu cuenta en el lance
        <a href="${process.env.BACKEND_URL}:${process.env.port ?? 3000}/auth/comprobar/${token}">confirmar cuenta </a>
    </p>

    <p> Si tu no creaste esta cuenta, puedes ignorar el correo </p>`

    })

}

export {
    emailRegistro
}