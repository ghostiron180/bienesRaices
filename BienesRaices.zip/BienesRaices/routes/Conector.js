import express from "express";
import { formularioLogin, formularioRegistro, formulRegistrar, comprobar, formularioOlvidePassword, resestPassword } from '../controllers/usuarioController.js'

const router = express.Router()

//Define get y post o conocido como //Routing
router.get("/login", formularioLogin)
router.get("/registro", formularioRegistro)
router.post("/registro", formulRegistrar)
router.get("/comprobar/:token", comprobar)


router.get("/recordarPassword", formularioOlvidePassword)
router.post("/recordarPassword", resestPassword)




export default router