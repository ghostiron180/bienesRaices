import { body, check, validationResult } from "express-validator"
import Usuario from "../models/Usuario.js"
import { generarId } from "../helpers/token.js"
import { emailRegistro } from "../helpers/email.js"
import usuario from "../models/Usuario.js"

const formularioLogin = (req, resp) => {

    resp.render('auth/login', {
        pagina: 'Iniciar Sesión'
    })
}

const formularioRegistro = (req, resp) => {
    resp.render('auth/registro', {
        pagina: 'Crear Cuenta',
        csrfToken: req.csrfToken()
    })
}

const formulRegistrar = async (req, resp) => {
    //validaciones
    await check('nombre').notEmpty().withMessage("El nombre no puede ir vacio").run(req)
    await check('email').isEmail().withMessage("No es un Email").run(req)
    await check('password').isLength({ min: 3 }).withMessage("Minimo 3 caracteres").run(req)
    await check('repetir_password').equals('password').withMessage("Los password no son iguales").run(req)
    // await check('edad').notEmpty().isLength({ min: 2 }).withMessage("falta edad").run(req)


    let resultado = validationResult(req)
    //resp.json(resultado.array())

    //verificar resultado vacio
    if (!resultado.isEmpty()) {
        //Errores
        return resp.render('auth/registro', {
            pagina: 'Crear cuenta',
            csrfToken: req.csrfToken(),
            errores: resultado.array(),
            usuario: {
                nombre: req.body.nombre,
                email: req.body.email,
                //edad: req.body.edad
            }
        })

    }

    //extraer los datos
    const { nombre, email, password } = req.body

    //Verificar que usuario no este duplicado
    const exiteUsuario = await Usuario.findOne({ where: { email } })

    if (exiteUsuario) {
        return resp.render('auth/registro', {
            pagina: 'Crear cuenta',
            csrfToken: req.csrfToken(),
            errores: [{ msg: 'El usuario ya esta registrado' }],
            usuario: {
                nombre: req.body.nombre,
                email: req.body.email
            }
        })

    }

    //almacenar Usuario
    const usuario = await Usuario.create({
        nombre,
        email,
        password,
        token: generarId()
    })

    console.log("Mensaje de Nicolay: ", usuario)

    //enviar Email de Confirmación
    emailRegistro({
        nombre: usuario.nombre,
        email: usuario.email,
        token: usuario.token

    })


    //mostrar mensaje de confirmación

    resp.render('templates/mensajes', {
        pagina: "Cuenta creada correctamente",
        mensaje: "Hemos enviado correo de confirmacion, presiona el enlace"
    })

}


//funcion que confirma una cuenta
const comprobar = async (req, resp) => {
    const { token } = req.params;
    console.log('Comprobando..', token);

    //verificar si el usuario es válido
    const usuario = await Usuario.findOne({ where: { token } })

    if (!usuario) {
        return resp.render('auth/confirmarCuenta', {
            pagina: "Error al confirmar cuenta",
            mensaje: "hubo un error al confirmar tu cuenta, confirma de nuevo",
            error: true
        })

    }

    //confirmar cuenta
    usuario.token = null;
    usuario.confirmado = true
    await usuario.save();

    resp.render('auth/confirmarCuenta', {
        pagina: "Cuenta Confirmada",
        mensaje: "la cuenta se confirmo correctamente"
    })

    console.log("prueba: ", usuario.token)


}


const formularioOlvidePassword = (req, resp) => {
    resp.render('auth/recordarPassword', {
        csrfToken: req.csrfToken(),
        password: 'Recordar Password'

    })
}

const resestPassword = (req, resp) => {

}

export {
    formularioLogin,
    formularioRegistro,
    formulRegistrar,
    comprobar,
    formularioOlvidePassword,
    resestPassword
}