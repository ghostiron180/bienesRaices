import express from 'express'
import csrf from 'csurf'
import cookieParser from 'cookie-parser'
import Conector from './routes/Conector.js'
import db from './config/db.js'



//Crear app
const app = express()

//habilitar lectura formulario
app.use(express.urlencoded({ extended: true }))

//habilitar cookie-parser
app.use(cookieParser())

//Habilitar CSRF
app.use(csrf({ cookie: true }))

//conector DB
try {
    await db.authenticate();
    db.sync()
    console.log('Conexion Correcta a DB')

} catch (error) {
    console.info("Error Conexion en DB")

}

//Habilitar Pug
app.set('view engine', 'pug')
app.set('views', './views')


//carpeta publica
app.use(express.static('public'))


//routing
app.use('/auth', Conector)


//definir proyecto y arrancar
const port = process.env.port || 3000;
app.listen(port, () => {
    console.log('Puerto funcionando ' + port)
})







